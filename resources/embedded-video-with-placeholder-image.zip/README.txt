A Pen created at CodePen.io. You can find this one at http://codepen.io/praliedutzel/pen/gbJzL.

 Creates a full-width embedded video with a placeholder image and a play button. When either the image or button are clicked, an iframe is loaded in, along with a close button.