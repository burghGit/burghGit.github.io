A Pen created at CodePen.io. You can find this one at http://codepen.io/JMChristensen/pen/qEqeWY.

 A couple of buttons to demonstrate Google's Material Design button ripple effect when being clicked.

I'll probably be making this into a simple plugin for myself soon.

Update: Fixed the border-radius clip issue and made it closer to native buttons based from Polymer.