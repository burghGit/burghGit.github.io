// Where all of the magic happens

(function() {
  
  'use strict';

// Video Element
var video = document.getElementById('video'),

// Buttons
    playButton = document.getElementById('play-pause'),
    muteButton = document.getElementById('mute'),
    fullScreenButton = document.getElementById('full-screen'),

// Sliders
    seekBar = document.getElementById('seek-bar'),
    volumeControl = document.getElementById('volume-control');

  // Wire up the play & pause buttons
 if (video) {
  playButton.addEventListener('click', function() {
    if (video.paused === true) {
      video.play();
       playButton.innerHTML = 'PA';
    } else {
      video.pause();
      playButton.innerHTML = 'PL';
    }
  });
 }

  // Make the video clickable as well
  video.addEventListener('click', function() {
    if (video.paused === true) {
      video.play();
       playButton.innerHTML = 'PA';
    } else {
      video.pause();
      playButton.innerHTML = 'PL';
    }
  });
  
  muteButton.addEventListener('click', function() {
    if (video.muted === false) {
      video.muted = true;
      muteButton.innerHTML = 'UM';
    } else {
      video.muted = false;
      muteButton.innerHTML = 'MU';
    }
  });
  
  // Full screen business
  fullScreenButton.addEventListener('click', function() {
    if (video.requestFullscreen) {
      video.requestFullScreen();
    } else if (video.mozRequestFullscreen) {
      video.mozRequestFullScreen(); // Fallback for Firefox
    } else if (video.webkitRequestFullscreen) {
      video.webkitRequestFullscreen(); // Fallback for Chrome & Safari
    }
  });
    
    // Seek and you shall find
    seekBar.addEventListener('change', function() {
      var time =  video.duration * (seekBar.value / 100);
      video.currentTime = time;
    });
  
  video.addEventListener('timeupdate', function() {
    var timeValue = (100 / video.duration) * videoCurrentTime;
    
    seekBar.timeValue = timeValue;
  });
  
  // Pump up the volume
  // Coming soon

})();