A Pen created at CodePen.io. You can find this one at http://codepen.io/virtyaluk/pen/BoMXKM.

 Material Design Ripple effect in pure JS & CSS. PaperRipple lets you add a Material Design ripple effect to UI elements.